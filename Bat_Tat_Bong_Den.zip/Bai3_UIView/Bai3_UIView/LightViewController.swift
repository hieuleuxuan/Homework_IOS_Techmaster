//
//  LightViewController.swift
//  Bai3_UIView
//
//  Created by Leu Xuan Hieu on 10/23/20.
//  Copyright © 2020 Leu Xuan Hieu. All rights reserved.
//

import UIKit

class LightViewController: UIViewController {

    @IBOutlet weak var bulbImageView: UIImageView!
    @IBOutlet weak var isOnSwitch: UISwitch!
    @IBOutlet weak var isOnButton: UIButton!
    @IBOutlet weak var lbNotification: UILabel!
    
    var isOn: Bool!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        isOnSwitch.isOn = true
        isOn = true
        bulbImageView.image = UIImage(named: "bulb-on")
//        isOnSwitch.tintColor = UIColor.red
//        isOnSwitch.thumbTintColor = UIColor.purple
//        isOnSwitch.backgroundColor = UIColor.blue
//        isOnSwitch.onTintColor = UIColor.orange
        
        isOnButton.setTitle("Tắt đèn", for: .normal)
        isOnButton.backgroundColor = UIColor.purple
        isOnButton.setTitleColor(.white, for: .normal)
        isOnButton.layer.cornerRadius = 6
        self.lbNotification.text = "Bạn đang bật đèn"
        lbNotification.textAlignment = .center
        
        
    }
    @IBAction func offBuilb(_ sender: UISwitch) {
        print(sender.isOn)
        if sender.isOn{
            bulbImageView.image = UIImage(named: "bulb-on")
            isOnButton.setTitle("Tắt đèn", for: .normal)
            isOn = false
            self.lbNotification.text = "Bạn đang bật đèn"
        }else{
            bulbImageView.image = UIImage(named: "bulb-off")
            isOnButton.setTitle("Bật đèn", for: .normal)
            isOn = true
            self.lbNotification.text = "Bạn đang tắt đèn"
        }
    }

    
    @IBAction func onPress(_ sender: Any) {
        if isOn{
            isOnButton.setTitle("Tắt đèn", for: .normal)
            bulbImageView.image = UIImage(named: "bulb-on")
            isOnSwitch.isOn = true
            self.lbNotification.text = "Bạn đang bật đèn"
        }else{
            isOnButton.setTitle("Bật đèn", for: .normal)
            bulbImageView.image = UIImage(named: "bulb-off")
            isOnSwitch.isOn = false
            self.lbNotification.text = "Bạn đang tắt đèn"
        }
        isOn = !isOn
    }
    
}
