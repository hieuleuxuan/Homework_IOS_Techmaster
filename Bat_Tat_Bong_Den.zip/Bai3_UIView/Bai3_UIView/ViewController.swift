//
//  ViewController.swift
//  Bai3_UIView
//
//  Created by Leu Xuan Hieu on 10/23/20.
//  Copyright © 2020 Leu Xuan Hieu. All rights reserved.
//

import UIKit

class ViewController: UIViewController {


    @IBOutlet weak var blueView: UIView!
    @IBOutlet weak var orangeView: UIView!
    @IBOutlet weak var greenView: UIView!
    
    let myView: UIView = {
        let xView = UIView()
        xView.backgroundColor = UIColor.red
        xView.frame = CGRect(x: 200, y: 200, width: 200, height: 200)
        xView.layer.cornerRadius = xView.bounds.height/2
        xView.clipsToBounds = true
        return xView
    }()
    
    let myView2: UIView = {
        let xView = UIView()
        xView.backgroundColor = UIColor.purple
        xView.frame = CGRect(x: 0, y: 0, width: 100, height: 100)
        return xView
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        view.backgroundColor = UIColor.white
        //Thay đổi kích thước của whiteView
        blueView.frame = CGRect(x: 0, y: 0, width: 200, height: 200)
        orangeView.frame = CGRect(x: 200, y: 200, width: 100, height: 200)
        greenView.frame = CGRect(x: 200, y: 400, width: 300, height: 50)
        greenView.center.x = orangeView.center.x
        
        print(greenView.bounds)
        
//        greenView.frame.origin.x = orangeView.bounds.origin.x
        
        orangeView.alpha = 0.5
//        alpha có giá trị từ 0 -> 1
        
        greenView.layer.cornerRadius = 20
        
//        Thêm myView vào superView
        view.addSubview(myView)
        myView.frame.origin.y = greenView.frame.maxY + 20
        print(greenView.frame.maxY)
        
        myView.addSubview(myView2)
    }


}

