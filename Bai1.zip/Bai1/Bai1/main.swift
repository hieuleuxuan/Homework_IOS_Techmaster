//
//  main.swift
//  Bai1
//
//  Created by Leu Xuan Hieu on 10/17/20.
//  Copyright © 2020 Leu Xuan Hieu. All rights reserved.
//

import Foundation

// MARK: -Đổi độ C sang độ F và ngược lại
var doC:Double = 30
var doF:Double = 86
var tinhDoC = (doF-32)/1.8
var tinhDoF = (doC*1.8+32)
print("\(doC) độ C bằng \(tinhDoF) độ F")
print("\(doF) độ F bằng \(tinhDoC) độ C")


//MARK: - Nhập 3 cạnh của tam giác, nếu đúng thì tính diện tích hình tam giác đó
var a:Double = 3
var b:Double = 4
var c:Double = 5
var chuvi = a+b+c
var nuachuvi = chuvi/2
var dientich = sqrt(nuachuvi*(nuachuvi-a)*(nuachuvi-b)*(nuachuvi-c))
print("Chu vi hình tam giác là: \(chuvi)")
print("Nửa chu vi hình tam giác là: \(nuachuvi)")
if a >= b + c || b >= a + c || c >= a + b{
    print("3 cạnh trên không phải là 3 cạnh của tam giác")
}else{
    print("Diện tích của tam giác là: \(dientich)")
}

//MARK: - Kiểm tra năm đó có phải là năm nhuận hay không

// Năm nhuận là năm chia hết cho 400
var nam:Int = 2017
if nam % 400 == 0{
    print("Năm \(nam) là năm nhuận")
}else{
    print("Năm \(nam) không phải là năm nhuận")
}

// Năm nhuận là năm chia hết cho 4 nhưng không chia hết cho 100
var Nam:Int = 2020
if Nam % 4 == 0 && nam % 100 != 0{
    print("Năm \(Nam) là năm nhuận")
}else{
    print("Năm \(Nam) không phải là năm nhuận")
}

func numbers(a:Int, b:Int){
    let min = a[0]
    let max = a[0]
}
