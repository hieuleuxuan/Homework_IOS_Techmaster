//
//  ViewController.swift
//  Baitap_Buoi2
//
//  Created by Leu Xuan Hieu on 10/23/20.
//  Copyright © 2020 Leu Xuan Hieu. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var btnDangNhap: UIButton!
    @IBOutlet weak var btnDangKy: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        nameLabel.text = "Chào mừng bạn đến với lớp học IOS"
        btnDangNhap.layer.cornerRadius = 6
        btnDangKy.layer.cornerRadius = 6
    }

}

